# HƯỚNG DẪN DEPLOY (CÀI ĐẶT) DANALOG PORTAL

Tài liệu này hướng dẫn cách deploy ứng dụng Danalog Portal lên môi trường server.

## Cách 1: Deploy bằng Docker (Khuyên dùng)
Đây là cách đơn giản nhất để chuyển giao cho bên vận hành (DevOps/IT).

**Yêu cầu:** Server đã cài đặt Docker.

**Các bước:**
1. Tải toàn bộ source code về server.
2. Tại thư mục gốc của dự án, chạy lệnh build image:
   ```bash
   docker build -t danalog-portal .
   ```
3. Chạy container:
   ```bash
   docker run -d -p 80:80 --name danalog-app danalog-portal
   ```
   Sau khi chạy xong, truy cập vào IP của server (cổng 80) để xem ứng dụng.

## Cách 2: Deploy thủ công (Web Server Nginx/Apache)

**Yêu cầu:** Server cài sẵn Node.js (để build) và Nginx (để chạy).

**Các bước:**
1. **Cài đặt thư viện:**
   ```bash
   npm install
   ```
2. **Build dự án:**
   ```bash
   npm run build
   ```
   Kết quả: Hệ thống sẽ tạo ra thư mục `dist` chứa code đã đóng gói.

3. **Deploy:**
   - Copy toàn bộ file trong thư mục `dist` vào thư mục web root của server (ví dụ `/var/www/html`).
   - **Quan trọng:** Cấu hình Nginx/Apache để redirect tất cả request về `index.html` (để hỗ trợ React Router).
     - *Tham khảo file `nginx.conf` đính kèm để xem cấu hình mẫu.*

## Cách 3: Deploy lên Vercel / Netlify (Cloud)
Nếu dùng dịch vụ Cloud miễn phí/trả phí:
1. Kết nối Repository với Vercel/Netlify.
2. Cấu hình Build Command: `npm run build`
3. Cấu hình Output Directory: `dist`
4. Deploy.

---
**Lưu ý:**
- Dữ liệu hiện tại đang sử dụng **MockBackend** (lưu trên trình duyệt người dùng - LocalStorage) và **tài khoản Admin mặc định** (`admin`/`123`).
- Nếu cần reset dữ liệu, hãy xóa Local Storage của trình duyệt.
