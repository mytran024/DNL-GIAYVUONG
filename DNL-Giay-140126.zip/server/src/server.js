const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '200mb' }));
app.use(express.urlencoded({ limit: '200mb', extended: true }));

// --- ROUTES ---

// 1. USERS
app.get('/api/users', (req, res) => {
    try {
        const users = db.prepare('SELECT * FROM users').all();
        // Convert integer booleans back to boolean if needed, though SQLite stores as 0/1
        const formatted = users.map(u => ({
            ...u,
            isActive: !!u.isActive
        }));
        res.json(formatted);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/users', (req, res) => {
    try {
        const { id, username, password, name, role, isActive, phoneNumber, department, createdAt } = req.body;

        // Check if updating or creating
        const existing = db.prepare('SELECT id FROM users WHERE id = ?').get(id);

        if (existing) {
            const stmt = db.prepare(`
                UPDATE users 
                SET username = ?, password = ?, name = ?, role = ?, isActive = ?, phoneNumber = ?, department = ?
                WHERE id = ?
            `);
            stmt.run(username, password, name, role, isActive ? 1 : 0, phoneNumber, department, id);
        } else {
            const stmt = db.prepare(`
                INSERT INTO users (id, username, password, name, role, isActive, phoneNumber, department, createdAt)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            stmt.run(id, username, password, name, role, isActive ? 1 : 0, phoneNumber, department || 'Kho', createdAt);
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/users/:id', (req, res) => {
    try {
        const { id } = req.params;
        db.prepare('DELETE FROM users WHERE id = ?').run(id);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 2. RESOURCE MANAGEMENT (Workers & Teams)
app.get('/api/workers', (req, res) => {
    const workers = db.prepare('SELECT * FROM workers').all();
    res.json(workers);
});

app.post('/api/workers', (req, res) => {
    const workers = req.body; // Expect array of workers or single? MockBackend sent full array.
    // To support MockBackend style "saveWorkers(array)", we might need to replace all or upsert.
    // For ApiService efficiency, we should probably switch to add/update individual, 
    // BUT to keep migration simple for now, let's support "Sync" (Replace All) or atomic upserts.

    // Let's implement robust "Upsert" logic for the array.
    const insert = db.prepare('INSERT OR REPLACE INTO workers (id, name, phoneNumber, department) VALUES (?, ?, ?, ?)');
    const deleteOld = db.prepare('DELETE FROM workers WHERE id NOT IN (' + workers.map(() => '?').join(',') + ')');

    const transaction = db.transaction((data) => {
        if (data.length > 0) {
            // Keep only IDs present in data (Sync logic) if that's what frontend expects (complete replace)
            // Or if frontend sends full list, we can just wipe and insert? 
            // "Wipe and Insert" is safest for "Sync" style from MockBackend.
            db.prepare('DELETE FROM workers').run();
            for (const w of data) insert.run(w.id, w.name, w.phoneNumber || '', w.department || 'Kho');
        } else {
            db.prepare('DELETE FROM workers').run();
        }
    });

    try {
        transaction(workers);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/teams', (req, res) => {
    const teams = db.prepare('SELECT * FROM teams').all();
    res.json(teams);
});

app.post('/api/teams', (req, res) => {
    const teams = req.body;
    const insert = db.prepare('INSERT OR REPLACE INTO teams (id, name, phoneNumber, department) VALUES (?, ?, ?, ?)');
    const transaction = db.transaction((data) => {
        db.prepare('DELETE FROM teams').run();
        for (const t of data) insert.run(t.id, t.name, t.phoneNumber || '', t.department || 'Kho');
    });

    try {
        transaction(teams);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 3. AUTH (Login)
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, password);
    if (user) {
        if (!user.isActive) return res.status(403).json({ error: 'Account locked' });
        res.json({
            success: true,
            user: { ...user, isActive: !!user.isActive }
        });
    } else {
        res.status(401).json({ error: 'Invalid credentials' });
    }
});

// 4. CONTAINERS
app.get('/api/containers', (req, res) => {
    try {
        const containers = db.prepare('SELECT * FROM containers').all();
        // Parse JSON fields if any (workerNames)
        const formatted = containers.map(c => ({
            ...c,
            // SQLite stores booleans as 0/1
            tallyApproved: !!c.tallyApproved,
            workOrderApproved: !!c.workOrderApproved,
            workerNames: c.workerNames ? JSON.parse(c.workerNames) : []
        }));
        res.json(formatted);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/containers', (req, res) => {
    const containers = req.body;
    // Massive upsert/sync strategy as Frontend often sends full list or updates
    // For simplicity with current frontend logic (which saves full list), we might stick to sync?
    // BUT containers are large. Let's see MockBackend.saveContainers saves ALL.
    // Optimizing this: 
    // Ideally frontend should update ONE. But for migration parity, we support Bulk Save.

    // To assume SAFETY, we will use Transaction.
    const insert = db.prepare(`
        INSERT OR REPLACE INTO containers 
        (id, vesselId, unitType, containerNo, size, sealNo, consignee, carrier, pkgs, weight, billNo, vendor, detExpiry, tkNhaVC, ngayTkNhaVC, tkDnlOla, ngayTkDnl, ngayKeHoach, noiHaRong, workerNames, status, updatedAt, tallyApproved, workOrderApproved, remarks, lastUrgedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const transaction = db.transaction((data) => {
        db.prepare('DELETE FROM containers').run(); // Clean slate for full sync. Caution: In production, better to diff.
        for (const c of data) {
            insert.run(
                c.id, c.vesselId, c.unitType, c.containerNo, c.size, c.sealNo, c.consignee, c.carrier,
                c.pkgs, c.weight, c.billNo, c.vendor, c.detExpiry,
                c.tkNhaVC || '', c.ngayTkNhaVC || '', c.tkDnlOla || '', c.ngayTkDnl || '', c.ngayKeHoach || '', c.noiHaRong || '',
                c.workerNames ? JSON.stringify(c.workerNames) : '[]',
                c.status, c.updatedAt,
                c.tallyApproved ? 1 : 0, c.workOrderApproved ? 1 : 0, c.remarks, c.lastUrgedAt
            );
        }
    });

    try {
        transaction(containers);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/containers/:id', (req, res) => {
    // Individual Update
    const c = req.body;
    try {
        const stmt = db.prepare(`
            UPDATE containers SET 
            status = ?, updatedAt = ?, tallyApproved = ?, workOrderApproved = ?, remarks = ?, workerNames = ?, lastUrgedAt = ?
            WHERE id = ?
        `);
        stmt.run(
            c.status, c.updatedAt, c.tallyApproved ? 1 : 0, c.workOrderApproved ? 1 : 0, c.remarks,
            c.workerNames ? JSON.stringify(c.workerNames) : '[]', c.lastUrgedAt, c.id
        );
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// 5. VESSELS
app.get('/api/vessels', (req, res) => {
    res.json(db.prepare('SELECT * FROM vessels').all());
});

app.post('/api/vessels', (req, res) => {
    const vessels = req.body;
    const insert = db.prepare('INSERT OR REPLACE INTO vessels (id, vesselName, voyageNo, commodity, consignee, totalContainers, totalPkgs, totalWeight, eta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const transaction = db.transaction((data) => {
        // Do NOT delete all vessels, as it violates foreign key constraints with containers table.
        // using INSERT OR REPLACE is sufficient for updates and new additions.
        for (const v of data) {
            insert.run(
                v.id,
                v.vesselName,
                v.voyageNo || '',
                v.commodity || '',
                v.consignee || '',
                v.totalContainers || 0,
                v.totalPkgs || 0,
                v.totalWeight || 0,
                v.eta || null
            );
        }
    });
    try { transaction(vessels); res.json({ success: true }); }
    catch (e) { res.status(500).json({ error: e.message }); }
});

// 6. TALLY REPORTS
app.get('/api/tally-reports', (req, res) => {
    try {
        const reports = db.prepare('SELECT * FROM tally_reports').all();
        const formatted = reports.map(r => ({
            ...r,
            items: r.items ? JSON.parse(r.items) : [],
            isHoliday: !!r.isHoliday,
            isWeekend: !!r.isWeekend
        }));
        res.json(formatted);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/tally-reports', (req, res) => {
    const r = req.body;
    const insertFields = `(id, vesselId, mode, shift, workDate, owner, consignee, workerCount, workerNames, mechanicalCount, mechanicalNames, equipment, vehicleNo, shipNo, vehicleType, items, createdAt, createdBy, isHoliday, isWeekend, status)`;
    const insertPlaceholders = `(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    if (Array.isArray(r)) {
        const insert = db.prepare(`INSERT OR REPLACE INTO tally_reports ${insertFields} VALUES ${insertPlaceholders}`);
        const tx = db.transaction((data) => {
            db.prepare('DELETE FROM tally_reports').run();
            for (const x of data) insert.run(
                x.id, x.vesselId, x.mode, x.shift, x.workDate, x.owner, x.consignee,
                x.workerCount || 0, x.workerNames || '', x.mechanicalCount || 0, x.mechanicalNames || '',
                x.equipment || '', x.vehicleNo || '', x.shipNo || '', x.vehicleType || '',
                JSON.stringify(x.items || []), x.createdAt || Date.now(), x.createdBy || '',
                x.isHoliday ? 1 : 0, x.isWeekend ? 1 : 0, x.status || 'NHAP'
            );
        });
        try { tx(r); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); }
    } else {
        try {
            const stmt = db.prepare(`INSERT OR REPLACE INTO tally_reports ${insertFields} VALUES ${insertPlaceholders}`);
            stmt.run(
                r.id, r.vesselId, r.mode, r.shift, r.workDate, r.owner, r.consignee,
                r.workerCount || 0, r.workerNames || '', r.mechanicalCount || 0, r.mechanicalNames || '',
                r.equipment || '', r.vehicleNo || '', r.shipNo || '', r.vehicleType || '',
                JSON.stringify(r.items || []), r.createdAt || Date.now(), r.createdBy || '',
                r.isHoliday ? 1 : 0, r.isWeekend ? 1 : 0, r.status || 'NHAP'
            );
            res.json({ success: true });
        } catch (e) { res.status(500).json({ error: e.message }); }
    }
});

// 7. WORK ORDERS
app.get('/api/work-orders', (req, res) => {
    const wos = db.prepare('SELECT * FROM work_orders').all();
    const formatted = wos.map(w => ({
        ...w,
        containerIds: JSON.parse(w.containerIds || '[]'),
        containerNos: JSON.parse(w.containerNos || '[]'),
        workerNames: JSON.parse(w.workerNames || '[]'),
        vehicleNos: JSON.parse(w.vehicleNos || '[]'),
        items: JSON.parse(w.items || '[]'),
        isHoliday: !!w.isHoliday,
        isWeekend: !!w.isWeekend
    }));
    res.json(formatted);
});

app.post('/api/work-orders', (req, res) => {
    const w = req.body;
    // Assuming single helper is enough for now, or handle Array if front sends array
    if (Array.isArray(w)) {
        const insert = db.prepare(`INSERT OR REPLACE INTO work_orders 
          (id, type, containerIds, containerNos, vesselId, teamName, workerNames, peopleCount, vehicleType, vehicleNos, shift, date, items, status, isHoliday, isWeekend, createdBy, tallyId)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

        const tx = db.transaction((data) => {
            db.prepare('DELETE FROM work_orders').run();
            for (const x of data) insert.run(
                x.id, x.type, JSON.stringify(x.containerIds), JSON.stringify(x.containerNos), x.vesselId, x.teamName, JSON.stringify(x.workerNames),
                x.peopleCount, x.vehicleType, JSON.stringify(x.vehicleNos), x.shift, x.date, JSON.stringify(x.items), x.status,
                x.isHoliday ? 1 : 0, x.isWeekend ? 1 : 0, x.createdBy, x.tallyId
            );
        });
        try { tx(w); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); }
    } else {
        try {
            const stmt = db.prepare(`INSERT OR REPLACE INTO work_orders 
            (id, type, containerIds, containerNos, vesselId, teamName, workerNames, peopleCount, vehicleType, vehicleNos, shift, date, items, status, isHoliday, isWeekend, createdBy, tallyId)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
            stmt.run(
                w.id, w.type, JSON.stringify(w.containerIds), JSON.stringify(w.containerNos), w.vesselId, w.teamName, JSON.stringify(w.workerNames),
                w.peopleCount, w.vehicleType, JSON.stringify(w.vehicleNos), w.shift, w.date, JSON.stringify(w.items), w.status,
                w.isHoliday ? 1 : 0, w.isWeekend ? 1 : 0, w.createdBy, w.tallyId
            );
            res.json({ success: true });
        } catch (e) { res.status(500).json({ error: e.message }); }
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
