const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// Ensure data directory exists
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'danalog.db');
const db = new Database(dbPath, { verbose: console.log });
db.pragma('journal_mode = WAL');

// Initialize Schema
const initSchema = () => {
    // USERS
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            isActive INTEGER DEFAULT 1,
            phoneNumber TEXT,
            department TEXT DEFAULT 'Kho',
            createdAt TEXT
        )
    `);

    // WORKERS (Resource Management)
    db.exec(`
        CREATE TABLE IF NOT EXISTS workers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phoneNumber TEXT,
            department TEXT DEFAULT 'Kho'
        )
    `);

    // TEAMS (Resource Management - Mechanical Teams)
    db.exec(`
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phoneNumber TEXT,
            department TEXT DEFAULT 'Kho'
        )
    `);

    // VESSELS
    db.exec(`
        CREATE TABLE IF NOT EXISTS vessels (
            id TEXT PRIMARY KEY,
            vesselName TEXT NOT NULL,
            voyageNo TEXT,
            commodity TEXT,
            consignee TEXT,
            totalContainers INTEGER DEFAULT 0,
            totalPkgs INTEGER DEFAULT 0,
            totalWeight REAL DEFAULT 0,
            eta TEXT
        )
    `);

    // CONTAINERS
    db.exec(`
        CREATE TABLE IF NOT EXISTS containers (
            id TEXT PRIMARY KEY,
            vesselId TEXT,
            unitType TEXT,
            containerNo TEXT,
            size TEXT,
            sealNo TEXT,
            consignee TEXT,
            carrier TEXT,
            pkgs INTEGER,
            weight REAL,
            billNo TEXT,
            vendor TEXT,
            detExpiry TEXT,
            tkNhaVC TEXT,
            ngayTkNhaVC TEXT,
            tkDnlOla TEXT,
            ngayTkDnl TEXT,
            ngayKeHoach TEXT,
            noiHaRong TEXT,
            workerNames TEXT,
            status TEXT DEFAULT 'PENDING',
            updatedAt TEXT,
            tallyApproved INTEGER DEFAULT 0,
            workOrderApproved INTEGER DEFAULT 0,
            remarks TEXT,
            lastUrgedAt TEXT,
            FOREIGN KEY(vesselId) REFERENCES vessels(id)
        )
    `);

    // TALLY REPORTS
    db.exec(`
        CREATE TABLE IF NOT EXISTS tally_reports (
            id TEXT PRIMARY KEY,
            vesselId TEXT,
            mode TEXT,
            shift TEXT,
            workDate TEXT,
            owner TEXT,
            consignee TEXT,
            workerCount INTEGER,
            workerNames TEXT,
            mechanicalCount INTEGER,
            mechanicalNames TEXT,
            equipment TEXT,
            vehicleNo TEXT,
            shipNo TEXT,
            vehicleType TEXT,
            items JSON,
            createdAt INTEGER,
            createdBy TEXT,
            isHoliday INTEGER DEFAULT 0,
            isWeekend INTEGER DEFAULT 0,
            status TEXT DEFAULT 'NHAP'
        )
    `);

    // WORK ORDERS
    db.exec(`
        CREATE TABLE IF NOT EXISTS work_orders (
            id TEXT PRIMARY KEY,
            type TEXT,
            containerIds JSON, -- Array of IDs
            containerNos JSON,
            vesselId TEXT,
            teamName TEXT,
            workerNames JSON,
            peopleCount INTEGER,
            vehicleType TEXT,
            vehicleNos JSON,
            shift TEXT,
            date TEXT,
            items JSON,
            status TEXT,
            isHoliday INTEGER,
            isWeekend INTEGER,
            createdBy TEXT,
            tallyId TEXT
        )
    `);

    // SEED DATA LOGIC
    const seedData = () => {
        // 1. Users
        const users = [
            { id: 'u-admin', username: 'admin', password: '1', name: 'Admin User', role: 'ADMIN' },
            { id: 'u-cs1', username: 'cs', password: '1', name: 'Nguyễn Thị CS', role: 'CS' },
            { id: 'u-kv1', username: 'kv1', password: '1', name: 'Trần Văn Kiểm', role: 'INSPECTOR' },
            { id: 'u-kv2', username: 'kv2', password: '1', name: 'Lê Văn Soát', role: 'INSPECTOR' }
        ];

        const userStmt = db.prepare('INSERT OR IGNORE INTO users (id, username, password, name, role, isActive, createdAt) VALUES (@id, @username, @password, @name, @role, 1, @createdAt)');
        users.forEach(u => userStmt.run({ ...u, createdAt: new Date().toISOString() }));

        // 2. Workers (Công nhân)
        const workers = [
            { id: 'w1', name: 'Nguyễn Văn Nam', phoneNumber: '0905111222' },
            { id: 'w2', name: 'Trần Văn Hùng', phoneNumber: '0905333444' },
            { id: 'w3', name: 'Lê Văn Tùng', phoneNumber: '0905555666' },
            { id: 'w4', name: 'Phạm Văn Tú', phoneNumber: '0905777888' },
            { id: 'w5', name: 'Đỗ Văn Minh', phoneNumber: '0905999000' }
        ];
        const workerStmt = db.prepare('INSERT OR IGNORE INTO workers (id, name, phoneNumber) VALUES (@id, @name, @phoneNumber)');
        workers.forEach(w => workerStmt.run(w));

        // 3. Teams (Cơ giới - Là người)
        const teams = [
            { id: 't1', name: 'Nguyễn Văn Tám', phoneNumber: '0905123123' },
            { id: 't2', name: 'Lê Văn Chín', phoneNumber: '0905456456' },
            { id: 't3', name: 'Trần Văn Mười', phoneNumber: '0905789789' },
            { id: 't4', name: 'Phạm Văn Tý', phoneNumber: '0905000111' }
        ];
        // Clear old equipment-based names if they exist to ensure update
        db.exec('DELETE FROM teams');

        const teamStmt = db.prepare('INSERT OR IGNORE INTO teams (id, name, phoneNumber) VALUES (@id, @name, @phoneNumber)');
        teams.forEach(t => teamStmt.run(t));

        // 4. Vessels
        const vessels = [
            {
                id: 'v1',
                vesselName: 'TÀU S30',
                voyageNo: 'V2026-05',
                eta: '05/01/2026',
                consignee: 'EASY SUCCUESS SHIPPING PTE LTD',
                totalContainers: 15,
                totalPkgs: 240,
                totalWeight: 432
            },
            {
                id: 'v2',
                vesselName: 'WAN HAI 302',
                voyageNo: 'N112',
                eta: '10/01/2026',
                consignee: 'SHINING LOGISTICS',
                totalContainers: 10,
                totalPkgs: 160,
                totalWeight: 300
            },
            {
                id: 'v3',
                vesselName: 'GLORY OCEAN',
                voyageNo: '2403N',
                eta: '15/01/2026',
                consignee: 'DA NANG PORT LOGISTICS (DPL)',
                totalContainers: 8,
                totalPkgs: 128,
                totalWeight: 230
            }
        ];
        const vesselStmt = db.prepare('INSERT OR IGNORE INTO vessels (id, vesselName, voyageNo, eta, consignee, totalContainers, totalPkgs, totalWeight) VALUES (@id, @vesselName, @voyageNo, @eta, @consignee, @totalContainers, @totalPkgs, @totalWeight)');
        vessels.forEach(v => vesselStmt.run(v));

        // 5. Containers
        const containers = [
            // v1
            { id: 'c1', vesselId: 'v1', containerNo: 'GESU6721400', size: '40HC', pkgs: 16, weight: 28.8, sealNo: 'H/25.0462426', vendor: 'SME', tkNhaVC: '500592570963', tkDnlOla: '500592633150', detExpiry: '07/01/2026' },
            { id: 'c2', vesselId: 'v1', containerNo: 'MEDU8466699', size: '40HC', pkgs: 16, weight: 28.8, sealNo: 'H/25.0462427', vendor: 'SME', tkNhaVC: '500592570964', tkDnlOla: '', detExpiry: '07/01/2026' },
            { id: 'c3', vesselId: 'v1', containerNo: 'MSMU4755070', size: '40HC', pkgs: 16, weight: 28.8, sealNo: 'H/25.0462430', vendor: 'SME', tkNhaVC: '500592570967', tkDnlOla: '500592633150', detExpiry: '07/01/2026' },
            { id: 'c4', vesselId: 'v1', containerNo: 'TXGU5463840', size: '40HC', pkgs: 16, weight: 28.8, sealNo: 'H/25.0462432', vendor: 'SME', tkNhaVC: '', tkDnlOla: '', detExpiry: '07/01/2026' },
            // v2
            { id: 'c101', vesselId: 'v2', containerNo: 'WHLU5723261', size: '40HC', pkgs: 16, weight: 28.8, sealNo: 'H/25.0462434', vendor: 'HDC', tkNhaVC: '500592570971', tkDnlOla: '500592633150', detExpiry: '17/01/2026' },
            // v3
            { id: 'c201', vesselId: 'v3', containerNo: '29D012.45/29R019.42', size: 'XE THỚT', pkgs: 16, weight: 26.5, sealNo: 'H/25.999001', vendor: 'Vận tải Thăng Long', tkNhaVC: '500592571001', tkDnlOla: '500592634001', detExpiry: '20/01/2026' },
            { id: 'c202', vesselId: 'v3', containerNo: '43C123.45/43R001.23', size: 'XE THỚT', pkgs: 16, weight: 27.2, sealNo: 'H/25.999002', vendor: 'Vận tải Đà Nẵng', tkNhaVC: '500592571002', tkDnlOla: '500592634002', detExpiry: '20/01/2026' },
            { id: 'c203', vesselId: 'v3', containerNo: '15C555.55/15R666.66', size: 'XE THỚT', pkgs: 16, weight: 25.8, sealNo: 'H/25.999003', vendor: 'Vận tải Hải Phòng', tkNhaVC: '500592571003', tkDnlOla: '500592634003', detExpiry: '20/01/2026' },
            { id: 'c204', vesselId: 'v3', containerNo: '51D888.12/51R888.34', size: 'XE THỚT', pkgs: 16, weight: 28.0, sealNo: 'H/25.999004', vendor: 'Sài Gòn Trans', tkNhaVC: '500592571004', tkDnlOla: '', detExpiry: '20/01/2026' },
        ];

        // Need to handle missing columns in containers table insert if schema differs,
        // specifically `billNo` (tkNhaVC) and `vendor` (assuming vendor map).
        // My previous schema said `billNo` but here I used `tkNhaVC`.
        // Let's assume schema has `billNo` mapped to `tkNhaVC` conceptually or update schema.
        // Actually, looking at DB schema: `billNo TEXT, vendor TEXT`.
        // I will map `tkNhaVC` -> `billNo`? No, `tkNhaVC` and `tkDnlOla` are specific.
        // Wait, schema in lines 69-90 didn't explicitly show `tkNhaVC` or `tkDnlOla`.
        // It showed: `billNo`.
        // I should check schema again. `billNo` seems to be the only text field for 'Bill/TK'.
        // But the frontend uses `tkNhaVC` and `tkDnlOla`.
        // I should ADD these columns to schema if missing or map them.
        // Let's add them to schema first to be safe.
    };

    // Auto-update schema for missing columns (simple migration)
    const alterColumns = [
        'tkNhaVC TEXT', 'ngayTkNhaVC TEXT', 'tkDnlOla TEXT', 'ngayTkDnl TEXT',
        'ngayKeHoach TEXT', 'noiHaRong TEXT', 'workerNames TEXT'
    ];
    for (const col of alterColumns) {
        try {
            db.exec(`ALTER TABLE containers ADD COLUMN ${col}`);
        } catch (e) { /* Column already exists */ }
    }

    seedData();
};

initSchema();

module.exports = db;
